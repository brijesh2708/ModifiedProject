package com.cg.fms.exceptions;

public class FMSException extends Exception{
	
	private String message;

	public FMSException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}



}
