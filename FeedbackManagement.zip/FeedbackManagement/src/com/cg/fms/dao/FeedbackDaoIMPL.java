package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.CourseFacultyMapBean;
import com.cg.fms.model.CourseMasterBean;
import com.cg.fms.model.FacultySkillMasterBean;
import com.cg.fms.model.LoginBean;
import com.cg.fms.model.TrainingProgramMaintain;
import com.cg.fms.model.feedbackBean;
import com.cg.fms.model.participantEnroll;
import com.cg.fms.model.viewFeedbackMaster;
import com.cg.fms.presentation.FMSMain;
import com.cg.fms.utility.JdbcUtility;

public class FeedbackDaoIMPL implements IFeedbackDao {
	static Logger logger = Logger.getLogger(FeedbackDaoIMPL.class);
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet res = null;

	@Override
	public String checkRole(LoginBean login) throws FMSException {
		connection = JdbcUtility.getConnection();
		logger.info(" Connection established ");
		String role = null;
		try {
			statement = connection.prepareStatement(QueryConstant.selectrole);
			statement.setString(1, login.getUsername());
			statement.setString(2, login.getPassword());
			res = statement.executeQuery();
			while (res.next()) {
				role = res.getString(1);
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);

		}
		return role;

	}

	@Override
	public int insertFacultySkill(FacultySkillMasterBean facultySkill)
			throws FMSException {
		connection = JdbcUtility.getConnection();
		int result = 0;
		try {
			statement = connection.prepareStatement(QueryConstant.insertQuery);
			statement.setString(1, facultySkill.getFacultyId());
			statement.setString(2, facultySkill.getFacultySkillSet());
			result = statement.executeUpdate();

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}

		return result;
	}

	@Override
	public int updateFacultySkillOper(FacultySkillMasterBean facultyupdateSkill)
			throws FMSException {
		connection = JdbcUtility.getConnection();
		int result = 0;
		try {
			statement = connection.prepareStatement(QueryConstant.updateQuery);
			statement.setString(1, facultyupdateSkill.getFacultySkillSet());
			statement.setString(2, facultyupdateSkill.getFacultyId());
			result = statement.executeUpdate();

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}
		return result;
	}

	@Override
	public int deletefacultySkilloper(String facultyId) throws FMSException {
		connection = JdbcUtility.getConnection();
		int result = 0;
		try {
			statement = connection.prepareStatement(QueryConstant.deleteQuery);
			statement.setString(1, facultyId);
			result = statement.executeUpdate();
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}
		return result;

	}

	@Override
	public List<FacultySkillMasterBean> viewAllFacultyDetails()
			throws FMSException {
		List<FacultySkillMasterBean> list = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryConstant.viewQuery);
			res = statement.executeQuery();
			while (res.next()) {
				String facultyId = res.getString(1);
				String facultySkill = res.getString(2);
				FacultySkillMasterBean facultybean = new FacultySkillMasterBean(
						facultyId, facultySkill);
				list.add(facultybean);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}

		return list;
	}

	@Override
	public List<CourseFacultyMapBean> viewMapDetails() throws FMSException {
		List<CourseFacultyMapBean> list = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryConstant.mapviewQuery);
			res = statement.executeQuery();
			while (res.next()) {
				String courseId = res.getString(1);
				String coursename = res.getString(2);
				String noOfDays = res.getString(3);
				String facultyId = res.getString(4);
				String facultySkill = res.getString(5);
				CourseFacultyMapBean mapbean = new CourseFacultyMapBean(
						courseId, coursename, noOfDays, facultyId, facultySkill);
				list.add(mapbean);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}
		return list;
	}

	@Override
	public int insertCourseDetails(CourseMasterBean courseBean)
			throws FMSException {
		connection = JdbcUtility.getConnection();
		int result = 0;
		try {
			statement = connection
					.prepareStatement(QueryConstant.insertCourseQuery);
			statement.setString(1, courseBean.getCourseId());
			statement.setString(2, courseBean.getCourseName());
			statement.setString(3, courseBean.getNoOfDays());

			result = statement.executeUpdate();

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}

		return result;
	}

	@Override
	public int updateCourseOper(CourseMasterBean courseBean1)
			throws FMSException {
		connection = JdbcUtility.getConnection();
		int result = 0;
		try {
			statement = connection
					.prepareStatement(QueryConstant.updateCourseQuery);
			statement.setString(1, courseBean1.getCourseName());
			statement.setString(2, courseBean1.getNoOfDays());
			statement.setString(3, courseBean1.getCourseId());
			result = statement.executeUpdate();

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}
		return result;
	}

	@Override
	public int deleteCourseoper(String courseId) throws FMSException {
		connection = JdbcUtility.getConnection();
		int result = 0;
		try {
			statement = connection
					.prepareStatement(QueryConstant.deleteCourseQuery);
			statement.setString(1, courseId);
			result = statement.executeUpdate();
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}
		return result;
	}

	@Override
	public List<CourseMasterBean> viewAllCourseDetails() throws FMSException {
		List<CourseMasterBean> list = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		try {
			statement = connection
					.prepareStatement(QueryConstant.viewCourseQuery);
			res = statement.executeQuery();
			while (res.next()) {
				String courseId = res.getString(1);
				String courseName = res.getString(2);
				String noOfDays = res.getString(3);
				CourseMasterBean coursebean = new CourseMasterBean(courseId,
						courseName, noOfDays);
				list.add(coursebean);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}

		return list;
	}

	@Override
	public List<TrainingProgramMaintain> fetchingTrainingProgramDetails()
			throws FMSException {
		List<TrainingProgramMaintain> list = new ArrayList<TrainingProgramMaintain>();
		connection = JdbcUtility.getConnection();
		try {
			statement = connection
					.prepareStatement(QueryConstant.viewTrainingProgramqry);
			res = statement.executeQuery();
			while (res.next()) {
				String trainingCode = res.getString(1);
				String participantId = res.getString(2);
				String courseId = res.getString(3);
				String courseName = res.getString(4);
				String noDays = res.getString(5);
				String facultyId = res.getString(6);
				String skillSet = res.getString(7);
				String startDate = res.getString(8);
				String endDate = res.getString(9);
				TrainingProgramMaintain maintaibTP = new TrainingProgramMaintain(
						trainingCode, participantId, courseId, courseName,
						noDays, facultyId, skillSet, startDate, endDate);
				list.add(maintaibTP);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}

		return list;
	}

	@Override
	public boolean getTrainingCode(String trainingCode) throws FMSException {
		boolean flag = false;
		connection = JdbcUtility.getConnection();
		try {
			statement = connection
					.prepareStatement(QueryConstant.checkTraineeCodeqry);
			res = statement.executeQuery();

			while (res.next()) {

				String trainingCoded = res.getString(1);
				if (trainingCode.equals(trainingCoded)) {
					flag = true;
					break;
				}
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}

		return flag;

	}

	@Override
	public boolean checkParticipantId(String participantId, String trainingCode)
			throws FMSException {
		boolean flag = false;
		connection = JdbcUtility.getConnection();
		try {
			statement = connection
					.prepareStatement(QueryConstant.checkParticipantIdqry);
			statement.setString(1, trainingCode);
			res = statement.executeQuery();
			while (res.next()) {
				String participantIdd = res.getString(1);
				if (participantId.equals(participantIdd)) {
					flag = true;
					break;
				}
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);

		}
		return flag;
	}

	@Override
	public int insertFeedback(feedbackBean fbBean) throws FMSException {
		int result = 0;
		connection = JdbcUtility.getConnection();
		try {
			statement = connection
					.prepareStatement(QueryConstant.insFeedbackQuery);
			statement.setString(1, fbBean.getTariningCode());
			statement.setString(2, fbBean.getParticipantId());
			statement.setString(3, fbBean.getFacultyId());
			statement.setString(4, fbBean.getFbPrsComm());
			statement.setString(5, fbBean.getFbClrfyDbts());
			statement.setString(6, fbBean.getFbTm());
			statement.setString(7, fbBean.getFbHndOut());
			statement.setString(8, fbBean.getFbHwSwNtwrk());
			statement.setString(9, fbBean.getComments());
			statement.setString(10, fbBean.getSuggestions());
			result = statement.executeUpdate();
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}
		return result;
	}

	@Override
	public String getParticipantId(LoginBean login) throws FMSException {
		ResultSet res = null;
		String participantId = null;
		connection = JdbcUtility.getConnection();
		try {
			statement = connection
					.prepareStatement(QueryConstant.getParticipantIdfqry);
			statement.setString(1, login.getUsername());
			statement.setString(2, login.getPassword());
			res = statement.executeQuery();
			res.next();

			participantId = res.getString(1);

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("Mismatch in the username and password");
		}
		return participantId;

	}

	@Override
	public int insertParticipant(participantEnroll penroll) throws FMSException {

		int res = 0;
		connection = JdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryConstant.insenrollqry);

			statement.setString(1, penroll.getTrainingCode());
			statement.setString(2, penroll.getParticipantId());

			res = statement.executeUpdate();

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}
		return res;

	}

	@Override
	public List<viewFeedbackMaster> viewAllFeedbackDetails() throws FMSException {
		List<viewFeedbackMaster> list = new ArrayList<viewFeedbackMaster>();
		connection = JdbcUtility.getConnection();
		ResultSet res=null;
		try {
			statement = connection.prepareStatement(QueryConstant.viewFeedbackDetailsqry);
			res=statement.executeQuery();
			while (res.next())
			{
				String tariningCode=res.getString(1);
				String participantId=res.getString(2);
				String facultId=res.getString(3);
				String fbPrsComm=res.getString(4);
				 String fbClrfyDbts=res.getString(5);
				 String fbTm=res.getString(6);
				 String fbHndOut=res.getString(7);
			 String fbHwSwNtwrk=res.getString(8);
				 String comments=res.getString(9);
				 String suggestions=res.getString(10);
				 viewFeedbackMaster viewfeedback=new viewFeedbackMaster(tariningCode,participantId,facultId,fbPrsComm,fbClrfyDbts,fbTm,fbHndOut,fbHwSwNtwrk,comments,suggestions);
			list.add(viewfeedback);
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}
		return list;
	}

	@Override
	public String fetchfacultyId(String trainingCode) throws FMSException {
		ResultSet res=null;
		String facultyId=null;
		connection = JdbcUtility.getConnection();
		try {
		
			statement = connection.prepareStatement(QueryConstant.fetchfacultyId);
			statement.setString(1, trainingCode);
			System.out.println("after stateemmt");
			res=statement.executeQuery();
			System.out.println("after query"+res);
			
			res.next();
		
				facultyId=res.getString(1);
				System.out.println(facultyId);
			
		
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new FMSException("statement not created " + e);
		}
		return facultyId;
		
	}

}
